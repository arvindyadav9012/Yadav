# NMRC INVENTORY - Android GitHub Build

This is the Android Studio project for NMRC INVENTORY.

## GitHub build
Upload all files in this folder to the repository root. Then open **Actions -> Build NMRC INVENTORY APK -> Run workflow**.

The repository includes an executable `gradlew` launcher. It downloads Gradle 8.9 on the GitHub runner, installs the required Android SDK packages, and builds `assembleDebug`.

The generated APK is available under the workflow run's **Artifacts** as `NMRC-INVENTORY-debug`.
